'use client'

import React, { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Header from '../components/Header'
import { useNotification } from '../contexts/NotificationContext'
import { useLanguage } from '../contexts/LanguageContext'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

interface Budget {
  id: string
  category: string
  amount: number
  spent: number
  month: number
  year: number
  alertThreshold: number
}

export default function BudgetPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { addNotification } = useNotification()
  const { t } = useLanguage()
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [newBudget, setNewBudget] = useState({
    category: '',
    amount: 0,
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    alertThreshold: 80,
  })
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1)
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login')
    } else if (status === 'authenticated') {
      fetchBudgets()
    }
  }, [status, router, selectedMonth, selectedYear])

  const fetchBudgets = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch(`/api/budgets?month=${selectedMonth}&year=${selectedYear}`)
      if (!response.ok) {
        throw new Error('Falha ao buscar orçamentos')
      }
      const data = await response.json()
      setBudgets(data)
    } catch (error) {
      console.error('Error fetching budgets:', error)
      setError('Erro ao carregar orçamentos. Por favor, tente novamente.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setNewBudget(prev => ({ ...prev, [name]: name === 'amount' || name === 'alertThreshold' ? parseFloat(value) : value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/budgets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newBudget),
      })

      if (!response.ok) {
        throw new Error('Falha ao adicionar orçamento')
      }

      const addedBudget = await response.json()
      setBudgets(prev => [...prev, addedBudget])
      setNewBudget({
        category: '',
        amount: 0,
        month: new Date().getMonth() + 1,
        year: new Date().getFullYear(),
        alertThreshold: 80,
      })
      addNotification('Orçamento adicionado com sucesso!', 'success')
    } catch (error) {
      console.error('Error adding budget:', error)
      addNotification('Erro ao adicionar orçamento. Por favor, tente novamente.', 'error')
    }
  }

  const chartData = {
    labels: budgets.map(budget => budget.category),
    datasets: [
      {
        label: t('budgeted'),
        data: budgets.map(budget => budget.amount),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
      {
        label: t('spent'),
        data: budgets.map(budget => budget.spent),
        backgroundColor: 'rgba(255, 99, 132, 0.6)',
      },
    ],
  }

  if (status === 'loading' || isLoading) {
    return <div>Carregando...</div>
  }

  if (error) {
    return <div className="text-red-500">{error}</div>
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-10 px-4">
        <h1 className="text-3xl font-bold mb-6">{t('budgets')}</h1>
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>{t('addNewBudget')}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700">{t('category')}</label>
                  <Input
                    type="text"
                    id="category"
                    name="category"
                    value={newBudget.category}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="amount" className="block text-sm font-medium text-gray-700">{t('amount')}</label>
                  <Input
                    type="number"
                    id="amount"
                    name="amount"
                    value={newBudget.amount}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="month" className="block text-sm font-medium text-gray-700">{t('month')}</label>
                  <Select
                    id="month"
                    name="month"
                    value={newBudget.month.toString()}
                    onValueChange={(value) => setNewBudget(prev => ({ ...prev, month: parseInt(value) }))}
                  >
                    <Select.Trigger className="w-full">
                      <Select.Value placeholder="Selecione o mês" />
                    </Select.Trigger>
                    <Select.Content>
                      {Array.from({ length: 12 }, (_, i) => (
                        <Select.Item key={i + 1} value={(i + 1).toString()}>
                          {new Date(0, i).toLocaleString('default', { month: 'long' })}
                        </Select.Item>
                      ))}
                    </Select.Content>
                  </Select>
                </div>
                <div>
                  <label htmlFor="year" className="block text-sm font-medium text-gray-700">{t('year')}</label>
                  <Input
                    type="number"
                    id="year"
                    name="year"
                    value={newBudget.year}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="alertThreshold" className="block text-sm font-medium text-gray-700">{t('alertThreshold')}</label>
                  <Input
                    type="number"
                    id="alertThreshold"
                    name="alertThreshold"
                    value={newBudget.alertThreshold}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              <Button type="submit" className="w-full">{t('addBudget')}</Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>{t('budgetList')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4 flex justify-between items-center">
              <Select
                value={selectedMonth.toString()}
                onValueChange={(value) => setSelectedMonth(parseInt(value))}
              >
                <Select.Trigger className="w-[180px]">
                  <Select.Value placeholder={t('selectMonth')} />
                </Select.Trigger>
                <Select.Content>
                  {Array.from({ length: 12 }, (_, i) => (
                    <Select.Item key={i + 1} value={(i + 1).toString()}>
                      {new Date(0, i).toLocaleString('default', { month: 'long' })}
                    </Select.Item>
                  ))}
                </Select.Content>
              </Select>
              <Select
                value={selectedYear.toString()}
                onValueChange={(value) => setSelectedYear(parseInt(value))}
              >
                <Select.Trigger className="w-[180px]">
                  <Select.Value placeholder={t('selectYear')} />
                </Select.Trigger>
                <Select.Content>
                  {Array.from({ length: 5 }, (_, i) => {
                    const year = new Date().getFullYear() - 2 + i
                    return (
                      <Select.Item key={year} value={year.toString()}>
                        {year}
                      </Select.Item>
                    )
                  })}
                </Select.Content>
              </Select>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {budgets.map((budget) => (
                <Card key={budget.id}>
                  <CardHeader>
                    <CardTitle>{budget.category}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Progress value={(budget.spent / budget.amount) * 100} className="w-full" />
                    <p className="mt-2">
                      {t('spent')}: ${budget.spent.toFixed(2)} / ${budget.amount.toFixed(2)}
                    </p>
                    <p className="text-sm text-gray-500">
                      {t('alertThreshold')}: {budget.alertThreshold}%
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="mt-8">
              <h3 className="text-xl font-semibold mb-4">{t('budgetComparison')}</h3>
              <Bar
                data={chartData}
                options={{
                  responsive: true,
                  scales: {
                    y: {
                      beginAtZero: true,
                    },
                  },
                }}
              />
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

