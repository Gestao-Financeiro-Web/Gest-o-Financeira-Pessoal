import React, { useState, useEffect } from 'react'
import { useGlobalState } from '../contexts/GlobalContext'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select } from "@/components/ui/select"
import { Pie, Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
} from 'chart.js'
import { useLanguage } from '../contexts/LanguageContext'

ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title
)

const Reports: React.FC = () => {
  const { t } = useLanguage()
  const [timeRange, setTimeRange] = useState('month')
  const [reportData, setReportData] = useState<any>(null)

  useEffect(() => {
    const fetchReportData = async () => {
      try {
        const response = await fetch(`/api/reports?timeRange=${timeRange}`)
        if (response.ok) {
          const data = await response.json()
          setReportData(data)
        } else {
          throw new Error('Failed to fetch report data')
        }
      } catch (error) {
        console.error('Error fetching report data:', error)
      }
    }

    fetchReportData()
  }, [timeRange])

  if (!reportData) {
    return <div>{t('loading')}</div>
  }

  const pieChartData = {
    labels: Object.keys(reportData.categoryData),
    datasets: [
      {
        data: Object.values(reportData.categoryData),
        backgroundColor: [
          '#FF6384',
          '#36A2EB',
          '#FFCE56',
          '#4BC0C0',
          '#9966FF',
          '#FF9F40',
        ],
      },
    ],
  }

  const barChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: t('income'),
        data: reportData.monthlyData.income,
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
      {
        label: t('expenses'),
        data: reportData.monthlyData.expenses,
        backgroundColor: 'rgba(255, 99, 132, 0.6)',
      },
    ],
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">{t('financialReports')}</h1>
      <div className="flex justify-end">
        <Select
          value={timeRange}
          onValueChange={(value) => setTimeRange(value)}
        >
          <Select.Trigger className="w-[180px]">
            <Select.Value placeholder={t('selectTimeRange')} />
          </Select.Trigger>
          <Select.Content>
            <Select.Item value="month">{t('thisMonth')}</Select.Item>
            <Select.Item value="year">{t('thisYear')}</Select.Item>
            <Select.Item value="all">{t('allTime')}</Select.Item>
          </Select.Content>
        </Select>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>{t('expensesByCategory')}</CardTitle>
          </CardHeader>
          <CardContent>
            <Pie data={pieChartData} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>{t('incomeVsExpenses')}</CardTitle>
          </CardHeader>
          <CardContent>
            <Bar
              data={barChartData}
              options={{
                responsive: true,
                scales: {
                  y: {
                    beginAtZero: true,
                  },
                },
              }}
            />
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>{t('summary')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <h3 className="font-semibold">{t('totalIncome')}</h3>
              <p className="text-2xl font-bold text-green-600">
                ${reportData.summary.totalIncome.toFixed(2)}
              </p>
            </div>
            <div>
              <h3 className="font-semibold">{t('totalExpenses')}</h3>
              <p className="text-2xl font-bold text-red-600">
                ${reportData.summary.totalExpenses.toFixed(2)}
              </p>
            </div>
            <div>
              <h3 className="font-semibold">{t('netSavings')}</h3>
              <p className="text-2xl font-bold text-blue-600">
                ${reportData.summary.netSavings.toFixed(2)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Reports

