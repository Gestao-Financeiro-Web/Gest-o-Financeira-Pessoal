// ... (previous imports)
import { SpendingTrendChart } from '../components/SpendingTrendChart'

// ... (previous code)

export default function BudgetDashboard() {
  // ... (previous state and effects)

  const [spendingTrend, setSpendingTrend] = useState<{
    labels: string[]
    datasets: {
      label: string
      data: number[]
      borderColor: string
      backgroundColor: string
    }[]
  }>({
    labels: [],
    datasets: [],
  })

  useEffect(() => {
    fetchSpendingTrend()
  }, [selectedYear])

  const fetchSpendingTrend = async () => {
    try {
      const response = await fetch(`/api/spending-trend?year=${selectedYear}`)
      if (!response.ok) {
        throw new Error('Falha ao buscar tendência de gastos')
      }
      const data = await response.json()
      setSpendingTrend(data)
    } catch (error) {
      console.error('Error fetching spending trend:', error)
    }
  }

  // ... (previous render code)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-10 px-4">
        {/* ... (previous content) */}
        
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>{t('spendingTrend')}</CardTitle>
          </CardHeader>
          <CardContent>
            <SpendingTrendChart data={spendingTrend} />
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

