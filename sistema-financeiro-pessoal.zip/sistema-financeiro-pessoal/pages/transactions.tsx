import React, { useState } from 'react'
import { useGlobalState } from '../contexts/GlobalContext'

const Transactions: React.FC = () => {
  const { state, dispatch } = useGlobalState()
  const [newTransaction, setNewTransaction] = useState({
    amount: '',
    description: '',
    category: '',
    date: '',
    type: 'expense' as 'income' | 'expense',
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setNewTransaction((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTransaction),
      })
      if (response.ok) {
        const addedTransaction = await response.json()
        dispatch({ type: 'ADD_TRANSACTION', payload: addedTransaction })
        setNewTransaction({
          amount: '',
          description: '',
          category: '',
          date: '',
          type: 'expense',
        })
      } else {
        throw new Error('Failed to add transaction')
      }
    } catch (error) {
      console.error('Error adding transaction:', error)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Transactions</h1>
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">Add New Transaction</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="amount" className="block mb-1">Amount</label>
              <input
                type="number"
                id="amount"
                name="amount"
                value={newTransaction.amount}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-md"
                required
              />
            </div>
            <div>
              <label htmlFor="description" className="block mb-1">Description</label>
              <input
                type="text"
                id="description"
                name="description"
                value={newTransaction.description}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-md"
                required
              />
            </div>
            <div>
              <label htmlFor="category" className="block mb-1">Category</label>
              <input
                type="text"
                id="category"
                name="category"
                value={newTransaction.category}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-md"
                required
              />
            </div>
            <div>
              <label htmlFor="date" className="block mb-1">Date</label>
              <input
                type="date"
                id="date"
                name="date"
                value={newTransaction.date}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-md"
                required
              />
            </div>
            <div>
              <label htmlFor="type" className="block mb-1">Type</label>
              <select
                id="type"
                name="type"
                value={newTransaction.type}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-md"
                required
              >
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </select>
            </div>
          </div>
          <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">
            Add Transaction
          </button>
        </form>
      </div>
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">Transaction History</h2>
        <table className="w-full">
          <thead>
            <tr className="text-left">
              <th className="pb-2">Date</th>
              <th className="pb-2">Description</th>
              <th className="pb-2">Category</th>
              <th className="pb-2">Amount</th>
              <th className="pb-2">Type</th>
            </tr>
          </thead>
          <tbody>
            {state.transactions.map((transaction) => (
              <tr key={transaction.id}>
                <td className="py-2">{new Date(transaction.date).toLocaleDateString()}</td>
                <td className="py-2">{transaction.description}</td>
                <td className="py-2">{transaction.category}</td>
                <td className="py-2">${transaction.amount.toFixed(2)}</td>
                <td className="py-2">
                  <span className={`px-2 py-1 rounded ${transaction.type === 'income' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>
                    {transaction.type}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Transactions

