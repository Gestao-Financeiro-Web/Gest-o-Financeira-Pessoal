import { QuickOverviewWidget } from '../components/QuickOverviewWidget'
import { ExportData } from '../components/ExportData'
import { Card, CardHeader, CardTitle, CardContent } from '../components/Card'
import { useTranslation } from 'react-i18next'

export default function Dashboard() {
  const { t } = useTranslation()

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">{t('dashboard')}</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <QuickOverviewWidget data={{
          totalBalance: 10000,
          monthlyIncome: 5000,
          monthlyExpenses: 3000,
          savingsGoalProgress: 75
        }} />
        <Card>
          <CardHeader>
            <CardTitle>{t('exportData')}</CardTitle>
          </CardHeader>
          <CardContent>
            <ExportData />
          </CardContent>
        </Card>
      </div>

      {/* ... resto do conteúdo do dashboard ... */}
    </div>
  )
}

