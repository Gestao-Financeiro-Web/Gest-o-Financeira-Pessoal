import React, { useState, useEffect } from 'react'
import { useGlobalState } from '../contexts/GlobalContext'
import { Progress } from "@/components/ui/progress"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useLanguage } from '../contexts/LanguageContext'

const Goals: React.FC = () => {
  const { state, dispatch } = useGlobalState()
  const { t } = useLanguage()
  const [newGoal, setNewGoal] = useState({
    name: '',
    targetAmount: '',
    currentAmount: '',
    deadline: '',
  })
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  useEffect(() => {
    const fetchGoals = async () => {
      try {
        const response = await fetch('/api/goals')
        if (response.ok) {
          const goals = await response.json()
          dispatch({ type: 'SET_GOALS', payload: goals })
        } else {
          throw new Error('Failed to fetch goals')
        }
      } catch (error) {
        console.error('Error fetching goals:', error)
      }
    }

    fetchGoals()
  }, [dispatch])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewGoal((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/goals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newGoal),
      })
      if (response.ok) {
        const addedGoal = await response.json()
        dispatch({ type: 'ADD_GOAL', payload: addedGoal })
        setNewGoal({
          name: '',
          targetAmount: '',
          currentAmount: '',
          deadline: '',
        })
        setIsDialogOpen(false)
      } else {
        throw new Error('Failed to add goal')
      }
    } catch (error) {
      console.error('Error adding goal:', error)
    }
  }

  const handleUpdateGoal = async (id: string, amount: number) => {
    try {
      const response = await fetch(`/api/goals/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentAmount: amount }),
      })
      if (response.ok) {
        const updatedGoal = await response.json()
        dispatch({ type: 'UPDATE_GOAL', payload: updatedGoal })
      } else {
        throw new Error('Failed to update goal')
      }
    } catch (error) {
      console.error('Error updating goal:', error)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">{t('goals')}</h1>
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button>{t('addNewGoal')}</Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{t('addNewGoal')}</DialogTitle>
            <DialogDescription>
              {t('setNewFinancialGoal')}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  {t('name')}
                </Label>
                <Input
                  id="name"
                  name="name"
                  value={newGoal.name}
                  onChange={handleInputChange}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="targetAmount" className="text-right">
                  {t('targetAmount')}
                </Label>
                <Input
                  id="targetAmount"
                  name="targetAmount"
                  type="number"
                  value={newGoal.targetAmount}
                  onChange={handleInputChange}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="currentAmount" className="text-right">
                  {t('currentAmount')}
                </Label>
                <Input
                  id="currentAmount"
                  name="currentAmount"
                  type="number"
                  value={newGoal.currentAmount}
                  onChange={handleInputChange}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="deadline" className="text-right">
                  {t('deadline')}
                </Label>
                <Input
                  id="deadline"
                  name="deadline"
                  type="date"
                  value={newGoal.deadline}
                  onChange={handleInputChange}
                  className="col-span-3"
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit">{t('addGoal')}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {state.goals.map((goal) => (
          <Card key={goal.id}>
            <CardHeader>
              <CardTitle>{goal.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <Progress value={(goal.currentAmount / goal.targetAmount) * 100} className="w-full" />
              <p className="mt-2">
                ${goal.currentAmount.toFixed(2)} / ${goal.targetAmount.toFixed(2)}
              </p>
              <p className="text-sm text-gray-500">
                {t('deadline')}: {new Date(goal.deadline).toLocaleDateString()}
              </p>
              <div className="mt-4">
                <Label htmlFor={`update-${goal.id}`}>{t('updateProgress')}</Label>
                <div className="flex items-center mt-1">
                  <Input
                    id={`update-${goal.id}`}
                    type="number"
                    placeholder={t('newAmount')}
                    className="mr-2"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        const input = e.target as HTMLInputElement
                        handleUpdateGoal(goal.id, parseFloat(input.value))
                        input.value = ''
                      }
                    }}
                  />
                  <Button
                    onClick={() => {
                      const input = document.getElementById(`update-${goal.id}`) as HTMLInputElement
                      handleUpdateGoal(goal.id, parseFloat(input.value))
                      input.value = ''
                    }}
                  >
                    {t('update')}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

export default Goals

