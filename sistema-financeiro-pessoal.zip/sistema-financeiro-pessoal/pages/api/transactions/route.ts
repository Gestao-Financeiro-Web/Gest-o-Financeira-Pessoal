import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { z } from 'zod'
import { autoCategorizeTx } from '@/utils/autoCategorizeTx'
import { sendEmail } from '@/utils/mailer'

// ... (previous code remains the same)

export async function POST(request: Request) {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  try {
    const json = await request.json()
    const body = transactionSchema.parse(json)

    const category = body.category || autoCategorizeTx(body)

    const transaction = await prisma.transaction.create({
      data: {
        ...body,
        category,
        userId: session.user.id
      }
    })

    // Atualizar o orçamento correspondente
    if (body.type === 'expense') {
      const date = new Date(body.date)
      const month = date.getMonth() + 1
      const year = date.getFullYear()

      const updatedBudget = await prisma.budget.updateMany({
        where: {
          userId: session.user.id,
          category: category,
          month: month,
          year: year
        },
        data: {
          spent: {
            increment: body.amount
          }
        }
      })

      // Verificar se o orçamento foi excedido
      const budget = await prisma.budget.findFirst({
        where: {
          userId: session.user.id,
          category: category,
          month: month,
          year: year
        }
      })

      if (budget && budget.spent > budget.amount) {
        const user = await prisma.user.findUnique({
          where: { id: session.user.id }
        })

        if (user) {
          await sendEmail(
            user.email,
            'Alerta de Orçamento Excedido',
            `<h1>Alerta de Orçamento Excedido</h1>
            <p>Olá ${user.name},</p>
            <p>Seu orçamento para a categoria "${category}" foi excedido.</p>
            <p>Orçamento: R$ ${budget.amount.toFixed(2)}</p>
            <p>Gasto atual: R$ ${budget.spent.toFixed(2)}</p>
            <p>Por favor, revise suas despesas e ajuste seu orçamento se necessário.</p>`
          )
        }
      }
    }

    return NextResponse.json(transaction)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }
    console.error('Error creating transaction:', error)
    return NextResponse.json({ error: 'Erro ao criar transação' }, { status: 500 })
  }
}

