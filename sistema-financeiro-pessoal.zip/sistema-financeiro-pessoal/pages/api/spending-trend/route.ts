import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'

export async function GET(request: Request) {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const year = searchParams.get('year')

  if (!year) {
    return NextResponse.json({ error: 'Ano não especificado' }, { status: 400 })
  }

  try {
    const transactions = await prisma.transaction.findMany({
      where: {
        userId: session.user.id,
        type: 'expense',
        date: {
          gte: new Date(`${year}-01-01`),
          lt: new Date(`${parseInt(year) + 1}-01-01`),
        },
      },
      orderBy: {
        date: 'asc',
      },
    })

    const monthlyTotals = Array(12).fill(0)
    transactions.forEach((transaction) => {
      const month = new Date(transaction.date).getMonth()
      monthlyTotals[month] += transaction.amount
    })

    const data = {
      labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
      datasets: [
        {
          label: 'Gastos Mensais',
          data: monthlyTotals,
          borderColor: 'rgb(75, 192, 192)',
          backgroundColor: 'rgba(75, 192, 192, 0.5)',
        },
      ],
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error('Error fetching spending trend:', error)
    return NextResponse.json({ error: 'Erro ao buscar tendência de gastos' }, { status: 500 })
  }
}

