import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { z } from 'zod'

const budgetSchema = z.object({
  category: z.string().min(1),
  amount: z.number().positive(),
  month: z.number().min(1).max(12),
  year: z.number().min(2000).max(2100),
  alertThreshold: z.number().min(1).max(100)
})

export async function GET(request: Request) {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const month = searchParams.get('month')
  const year = searchParams.get('year')

  try {
    const budgets = await prisma.budget.findMany({
      where: {
        userId: session.user.id,
        ...(month && { month: parseInt(month) }),
        ...(year && { year: parseInt(year) }),
      },
      orderBy: [
        { year: 'desc' },
        { month: 'desc' },
        { category: 'asc' }
      ]
    })
    return NextResponse.json(budgets)
  } catch (error) {
    console.error('Error fetching budgets:', error)
    return NextResponse.json({ error: 'Erro ao buscar orçamentos' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  try {
    const json = await request.json()
    const body = budgetSchema.parse(json)

    const budget = await prisma.budget.create({
      data: {
        ...body,
        userId: session.user.id,
        spent: 0
      }
    })

    return NextResponse.json(budget)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }
    console.error('Error creating budget:', error)
    return NextResponse.json({ error: 'Erro ao criar orçamento' }, { status: 500 })
  }
}

