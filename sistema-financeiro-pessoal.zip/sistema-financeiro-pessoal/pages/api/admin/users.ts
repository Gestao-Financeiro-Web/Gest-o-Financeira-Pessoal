import { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { authenticate, authorize } from '../../../middleware/auth';
import logger from '../../../utils/logger';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  await authenticate(req, res, async () => {
    await authorize(['admin'])(req, res, async () => {
      switch (req.method) {
        case 'GET':
          try {
            const users = await prisma.user.findMany({
              select: { id: true, name: true, email: true, role: true, createdAt: true },
            });
            res.status(200).json(users);
          } catch (error) {
            logger.error('Error fetching users:', error);
            res.status(500).json({ message: 'Error fetching users' });
          }
          break;

        default:
          res.setHeader('Allow', ['GET']);
          res.status(405).end(`Method ${req.method} Not Allowed`);
      }
    });
  });
}

