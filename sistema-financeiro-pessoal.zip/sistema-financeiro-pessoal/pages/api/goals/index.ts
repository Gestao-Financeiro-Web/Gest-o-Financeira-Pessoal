import { NextApiRequest, NextApiResponse } from 'next'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { z } from 'zod'

const goalSchema = z.object({
  name: z.string().min(1),
  targetAmount: z.number().positive(),
  currentAmount: z.number().nonnegative(),
  deadline: z.string().regex(/^\d{4}-\d{2}-\d{2}$/)
})

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession({ req, res })
  if (!session) {
    return res.status(401).json({ error: 'Não autorizado' })
  }

  switch (req.method) {
    case 'GET':
      try {
        const goals = await prisma.goal.findMany({
          where: { userId: session.user.id },
          orderBy: { deadline: 'asc' }
        })
        return res.status(200).json(goals)
      } catch (error) {
        console.error('Error fetching goals:', error)
        return res.status(500).json({ error: 'Erro ao buscar metas' })
      }

    case 'POST':
      try {
        const json = await req.body
        const body = goalSchema.parse(json)

        const goal = await prisma.goal.create({
          data: {
            ...body,
            userId: session.user.id
          }
        })

        return res.status(201).json(goal)
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ error: error.errors })
        }
        console.error('Error creating goal:', error)
        return res.status(500).json({ error: 'Erro ao criar meta' })
      }

    default:
      res.setHeader('Allow', ['GET', 'POST'])
      res.status(405).end(`Method ${req.method} Not Allowed`)
  }
}

