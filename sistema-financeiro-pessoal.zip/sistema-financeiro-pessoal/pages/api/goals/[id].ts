import { NextApiRequest, NextApiResponse } from 'next'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { z } from 'zod'

const updateGoalSchema = z.object({
  currentAmount: z.number().nonnegative()
})

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession({ req, res })
  if (!session) {
    return res.status(401).json({ error: 'Não autorizado' })
  }

  const { id } = req.query

  switch (req.method) {
    case 'PATCH':
      try {
        const json = await req.body
        const body = updateGoalSchema.parse(json)

        const updatedGoal = await prisma.goal.update({
          where: {
            id: id as string,
            userId: session.user.id
          },
          data: body
        })

        return res.status(200).json(updatedGoal)
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ error: error.errors })
        }
        console.error('Error updating goal:', error)
        return res.status(500).json({ error: 'Erro ao atualizar meta' })
      }

    default:
      res.setHeader('Allow', ['PATCH'])
      res.status(405).end(`Method ${req.method} Not Allowed`)
  }
}

