import { NextApiRequest, NextApiResponse } from 'next'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession({ req, res })
  if (!session) {
    return res.status(401).json({ error: 'Não autorizado' })
  }

  if (req.method === 'GET') {
    try {
      const { timeRange } = req.query
      const userId = session.user.id

      let startDate: Date
      const endDate = new Date()

      switch (timeRange) {
        case 'month':
          startDate = new Date(endDate.getFullYear(), endDate.getMonth(), 1)
          break
        case 'year':
          startDate = new Date(endDate.getFullYear(), 0, 1)
          break
        default:
          startDate = new Date(0) // All time
      }

      const transactions = await prisma.transaction.findMany({
        where: {
          userId,
          date: {
            gte: startDate,
            lte: endDate
          }
        }
      })

      const categoryData: { [key: string]: number } = {}
      const monthlyData = {
        income: new Array(12).fill(0),
        expenses: new Array(12).fill(0)
      }

      transactions.forEach((transaction) => {
        if (transaction.type === 'expense') {
          categoryData[transaction.category] = (categoryData[transaction.category] || 0) + transaction.amount
        }

        const month = new Date(transaction.date).getMonth()
        if (transaction.type === 'income') {
          monthlyData.income[month] += transaction.amount
        } else {
          monthlyData.expenses[month] += transaction.amount
        }
      })

      const totalIncome = monthlyData.income.reduce((a, b) => a + b, 0)
      const totalExpenses = monthlyData.expenses.reduce((a, b) => a + b, 0)

      return res.status(200).json({
        categoryData,
        monthlyData,
        summary: {
          totalIncome,
          totalExpenses,
          netSavings: totalIncome - totalExpenses
        }
      })
    } catch (error) {
      console.error('Error generating report:', error)
      return res.status(500).json({ error: 'Erro ao gerar relatório' })
    }
  }

  res.setHeader('Allow', ['GET'])
  res.status(405).end(`Method ${req.method} Not Allowed`)
}

