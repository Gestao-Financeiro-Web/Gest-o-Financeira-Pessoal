import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Transaction } from '@prisma/client'

export function useTransactions() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { data: session } = useSession()

  useEffect(() => {
    if (session?.user) {
      fetchTransactions()
    }
  }, [session])

  const fetchTransactions = async () => {
    try {
      setIsLoading(true)
      const response = await fetch('/api/transactions')
      if (!response.ok) {
        throw new Error('Falha ao carregar transações')
      }
      const data = await response.json()
      setTransactions(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido')
    } finally {
      setIsLoading(false)
    }
  }

  const addTransaction = async (newTransaction: Omit<Transaction, 'id' | 'userId'>) => {
    try {
      const response = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTransaction),
      })
      if (!response.ok) {
        throw new Error('Falha ao adicionar transação')
      }
      const addedTransaction = await response.json()
      setTransactions([...transactions, addedTransaction])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido')
    }
  }

  const updateTransaction = async (id: string, updatedTransaction: Partial<Transaction>) => {
    try {
      const response = await fetch(`/api/transactions/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedTransaction),
      })
      if (!response.ok) {
        throw new Error('Falha ao atualizar transação')
      }
      const updated = await response.json()
      setTransactions(transactions.map(t => t.id === id ? updated : t))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido')
    }
  }

  const deleteTransaction = async (id: string) => {
    try {
      const response = await fetch(`/api/transactions/${id}`, {
        method: 'DELETE',
      })
      if (!response.ok) {
        throw new Error('Falha ao excluir transação')
      }
      setTransactions(transactions.filter(t => t.id !== id))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido')
    }
  }

  return { transactions, isLoading, error, addTransaction, updateTransaction, deleteTransaction }
}

