import React, { useState, useEffect } from 'react'
import { Bell, X } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { useLanguage } from '../contexts/LanguageContext'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"

type Notification = {
  id: string
  title: string
  message: string
  type: 'info' | 'warning' | 'success' | 'error'
  createdAt: Date
}

export function NotificationCenter() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const { data: session } = useSession()
  const { t } = useLanguage()

  useEffect(() => {
    if (session) {
      // Fetch notifications from API
      fetchNotifications()
    }
  }, [session])

  const fetchNotifications = async () => {
    try {
      const response = await fetch('/api/notifications')
      if (response.ok) {
        const data = await response.json()
        setNotifications(data)
      }
    } catch (error) {
      console.error('Failed to fetch notifications:', error)
    }
  }

  const markAsRead = async (id: string) => {
    try {
      await fetch(`/api/notifications/${id}`, { method: 'PUT' })
      setNotifications(notifications.filter(n => n.id !== id))
    } catch (error) {
      console.error('Failed to mark notification as read:', error)
    }
  }

  const toggleNotifications = () => setIsOpen(!isOpen)

  return (
    <div className="relative">
      <Button
        onClick={toggleNotifications}
        variant="ghost"
        size="icon"
        className="relative"
        aria-label={t('toggleNotifications')}
      >
        <Bell />
        {notifications.length > 0 && (
          <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
            {notifications.length}
          </span>
        )}
      </Button>
      {isOpen && (
        <Card className="absolute right-0 mt-2 w-80 z-50">
          <CardHeader>
            <CardTitle>{t('notifications')}</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px]">
              {notifications.length === 0 ? (
                <p className="text-center text-gray-500">{t('noNotifications')}</p>
              ) : (
                notifications.map((notification) => (
                  <div key={notification.id} className="mb-4 p-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
                    <div className="flex justify-between items-start">
                      <h3 className="font-semibold">{notification.title}</h3>
                      <Button
                        onClick={() => markAsRead(notification.id)}
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        aria-label={t('markAsRead')}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-sm mt-1">{notification.message}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      {new Date(notification.createdAt).toLocaleString()}
                    </p>
                  </div>
                ))
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

