import React, { useEffect, useState } from 'react'
import { useNotification } from '../contexts/NotificationContext'
import { useLanguage } from '../contexts/LanguageContext'

interface Budget {
  id: string
  category: string
  amount: number
  spent: number
  month: number
  year: number
}

export function BudgetNotifications() {
  const [budgets, setBudgets] = useState<Budget[]>([])
  const { addNotification } = useNotification()
  const { t } = useLanguage()

  useEffect(() => {
    const fetchBudgets = async () => {
      try {
        const response = await fetch('/api/budgets')
        if (response.ok) {
          const data = await response.json()
          setBudgets(data)
        } else {
          throw new Error('Failed to fetch budgets')
        }
      } catch (error) {
        console.error('Error fetching budgets:', error)
      }
    }

    fetchBudgets()
  }, [])

  useEffect(() => {
    budgets.forEach((budget) => {
      const percentageSpent = (budget.spent / budget.amount) * 100
      if (percentageSpent >= 80 && percentageSpent < 100) {
        addNotification(
          t('budgetWarning', { category: budget.category, percentage: percentageSpent.toFixed(0) }),
          'warning'
        )
      } else if (percentageSpent >= 100) {
        addNotification(
          t('budgetExceeded', { category: budget.category }),
          'error'
        )
      }
    })
  }, [budgets, addNotification, t])

  return null // Este componente não renderiza nada, apenas gerencia notificações
}

