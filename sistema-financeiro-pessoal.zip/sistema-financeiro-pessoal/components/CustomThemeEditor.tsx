import React from 'react'
import { useTheme } from '../contexts/ThemeContext'
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"

export function CustomThemeEditor() {
  const { customTheme, setCustomTheme } = useTheme()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setCustomTheme(prev => ({ ...prev, [name]: value }))
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Personalizar Tema</h2>
      {Object.entries(customTheme).map(([key, value]) => (
        <div key={key}>
          <Label htmlFor={key}>{key.charAt(0).toUpperCase() + key.slice(1)}</Label>
          <Input
            type="color"
            id={key}
            name={key}
            value={value}
            onChange={handleChange}
          />
        </div>
      ))}
      <Button onClick={() => setCustomTheme({ ...customTheme })}>Aplicar Tema</Button>
    </div>
  )
}

