import React, { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useLanguage } from '../contexts/LanguageContext'
import { Download } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"

export function ExportData() {
  const [exportType, setExportType] = useState<'csv' | 'json'>('csv')
  const { data: session } = useSession()
  const { t } = useLanguage()

  const handleExport = async () => {
    if (!session) {
      toast({
        title: t('error'),
        description: t('mustBeLoggedIn'),
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch(`/api/export?type=${exportType}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.style.display = 'none'
        a.href = url
        a.download = `financial_data.${exportType}`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        toast({
          title: t('success'),
          description: t('dataExported'),
        })
      } else {
        throw new Error('Export failed')
      }
    } catch (error) {
      console.error('Export error:', error)
      toast({
        title: t('error'),
        description: t('exportFailed'),
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex items-center space-x-2">
      <Select value={exportType} onValueChange={(value: 'csv' | 'json') => setExportType(value)}>
        <SelectTrigger className="w-[180px]">
          <SelectValue placeholder={t('selectExportType')} />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="csv">CSV</SelectItem>
          <SelectItem value="json">JSON</SelectItem>
        </SelectContent>
      </Select>
      <Button onClick={handleExport} disabled={!session}>
        <Download className="mr-2 h-4 w-4" />
        {t('exportData')}
      </Button>
    </div>
  )
}

