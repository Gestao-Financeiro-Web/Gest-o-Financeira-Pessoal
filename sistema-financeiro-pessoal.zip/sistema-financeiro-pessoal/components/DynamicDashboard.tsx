import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'

const DynamicQuickOverviewWidget = dynamic(() => import('./QuickOverviewWidget'), {
  loading: () => <Skeleton className="h-[200px] w-full" />,
})

const DynamicTransactionList = dynamic(() => import('./TransactionList'), {
  loading: () => <Skeleton className="h-[400px] w-full" />,
})

const DynamicBudgetOverview = dynamic(() => import('./BudgetOverview'), {
  loading: () => <Skeleton className="h-[300px] w-full" />,
})

export function DynamicDashboard() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <DynamicQuickOverviewWidget />
      <DynamicTransactionList />
      <DynamicBudgetOverview />
    </div>
  )
}

