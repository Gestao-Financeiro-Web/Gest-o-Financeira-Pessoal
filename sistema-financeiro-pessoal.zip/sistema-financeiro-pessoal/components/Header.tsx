import Link from 'next/link'
import Image from 'next/image'
import { useSession, signOut } from 'next-auth/react'
import { ThemeToggle } from './ThemeToggle'
import { CustomThemeEditor } from './CustomThemeEditor'
import { Menu, Database, BarChart } from 'lucide-react'
import { useState } from 'react'
import { LanguageSwitcher } from './LanguageSwitcher'
import { useLanguage } from '../contexts/LanguageContext'
import { Dialog, DialogContent, DialogTrigger, Button } from "@/components/ui/dialog"
import { NotificationCenter } from './NotificationCenter'

function Header() {
  const { data: session } = useSession()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { t } = useLanguage()

  return (
    <header className="bg-background text-foreground shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <Image
            src="/logo.webp"
            alt="Sistema Financeiro Pessoal Logo"
            width={40}
            height={40}
            className="mr-2"
          />
          <span className="text-xl font-bold">
            Sistema Financeiro Pessoal
          </span>
        </Link>
        <div className="hidden md:flex items-center space-x-4">
          {session ? (
            <>
              <Link href="/dashboard" className="hover:text-primary">
                {t('dashboard')}
              </Link>
              <Link href="/transactions" className="hover:text-primary">
                {t('transactions')}
              </Link>
              <Link href="/goals" className="hover:text-primary">
                {t('goals')}
              </Link>
              <Link href="/budget" className="hover:text-primary">
                {t('budget')}
              </Link>
              <Link href="/reports" className="hover:text-primary">
                <BarChart className="inline-block mr-1" size={18} />
                {t('reports')}
              </Link>
              <Link href="/backup" className="hover:text-primary">
                <Database className="inline-block mr-1" size={18} />
                {t('backup')}
              </Link>
              <button onClick={() => signOut()} className="hover:text-primary">
                {t('logout')}
              </button>
            </>
          ) : (
            <Link href="/login" className="hover:text-primary">
              {t('login')}
            </Link>
          )}
          <NotificationCenter />
          <LanguageSwitcher />
          <ThemeToggle />
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">Personalizar Tema</Button>
            </DialogTrigger>
            <DialogContent>
              <CustomThemeEditor />
            </DialogContent>
          </Dialog>
        </div>
        <div className="md:hidden">
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-foreground">
            <Menu size={24} />
          </button>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden bg-background py-2">
          {session ? (
            <>
              <Link href="/dashboard" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                {t('dashboard')}
              </Link>
              <Link href="/transactions" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                {t('transactions')}
              </Link>
              <Link href="/goals" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                {t('goals')}
              </Link>
              <Link href="/budget" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                {t('budget')}
              </Link>
              <Link href="/reports" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                <BarChart className="inline-block mr-1" size={18} />
                {t('reports')}
              </Link>
              <Link href="/backup" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                <Database className="inline-block mr-1" size={18} />
                {t('backup')}
              </Link>
              <button onClick={() => signOut()} className="block w-full text-left px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                {t('logout')}
              </button>
            </>
          ) : (
            <Link href="/login" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
              {t('login')}
            </Link>
          )}
          <div className="px-4 py-2">
            <NotificationCenter />
          </div>
          <div className="px-4 py-2">
            <ThemeToggle />
          </div>
        </div>
      )}
    </header>
  )
}

export default Header

