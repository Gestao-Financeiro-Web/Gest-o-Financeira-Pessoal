import React from 'react'
import Link from 'next/link'

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-wrap justify-between">
          <div className="w-full md:w-1/3 mb-6 md:mb-0">
            <h3 className="text-lg font-semibold mb-2 text-gray-800 dark:text-white">
              Sistema Financeiro Pessoal
            </h3>
            <p className="text-gray-600 dark:text-gray-300">
              Gerencie suas finanças de forma eficiente e alcance seus objetivos financeiros.
            </p>
          </div>
          <div className="w-full md:w-1/3 mb-6 md:mb-0">
            <h4 className="text-lg font-semibold mb-2 text-gray-800 dark:text-white">Links Rápidos</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/dashboard">
                  <a className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                    Dashboard
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/transactions">
                  <a className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                    Transações
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/goals">
                  <a className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                    Metas
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/reports">
                  <a className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                    Relatórios
                  </a>
                </Link>
              </li>
            </ul>
          </div>
          <div className="w-full md:w-1/3">
            <h4 className="text-lg font-semibold mb-2 text-gray-800 dark:text-white">Contato</h4>
            <p className="text-gray-600 dark:text-gray-300 mb-2">
              Email: suporte@sistemafinanceiropessoal.com
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              Telefone: (11) 1234-5678
            </p>
          </div>
        </div>
        <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-8 text-center">
          <p className="text-gray-600 dark:text-gray-300">
            © {new Date().getFullYear()} Sistema Financeiro Pessoal. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer

