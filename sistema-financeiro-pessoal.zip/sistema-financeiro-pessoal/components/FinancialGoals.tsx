import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Progress } from '@/components/ui/progress'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useToast } from '@/components/ui/use-toast'
import { useLanguage } from '@/contexts/LanguageContext'

type Goal = {
  id: string
  name: string
  targetAmount: number
  currentAmount: number
  deadline: Date
}

export function FinancialGoals() {
  const [goals, setGoals] = useState<Goal[]>([])
  const { data: session } = useSession()
  const { toast } = useToast()
  const { t } = useLanguage()

  useEffect(() => {
    if (session?.user) {
      fetchGoals()
    }
  }, [session])

  const fetchGoals = async () => {
    const response = await fetch('/api/goals')
    if (response.ok) {
      const data = await response.json()
      setGoals(data)
    }
  }

  const addGoal = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = event.currentTarget
    const formData = new FormData(form)
    const newGoal = {
      name: formData.get('name') as string,
      targetAmount: Number(formData.get('targetAmount')),
      currentAmount: 0,
      deadline: new Date(formData.get('deadline') as string),
    }

    const response = await fetch('/api/goals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newGoal),
    })

    if (response.ok) {
      const addedGoal = await response.json()
      setGoals([...goals, addedGoal])
      form.reset()
      toast({
        title: t('goalAdded'),
        description: t('goalAddedDescription'),
      })
    }
  }

  const updateGoalProgress = async (id: string, amount: number) => {
    const response = await fetch(`/api/goals/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentAmount: amount }),
    })

    if (response.ok) {
      const updatedGoal = await response.json()
      setGoals(goals.map(goal => goal.id === id ? updatedGoal : goal))
      checkGoalCompletion(updatedGoal)
    }
  }

  const checkGoalCompletion = (goal: Goal) => {
    if (goal.currentAmount >= goal.targetAmount) {
      toast({
        title: t('goalAchieved'),
        description: t('goalAchievedDescription', { name: goal.name }),
      })
    }
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t('financialGoals')}</h2>
      <form onSubmit={addGoal} className="space-y-4">
        <Input name="name" placeholder={t('goalName')} required />
        <Input name="targetAmount" type="number" placeholder={t('targetAmount')} required />
        <Input name="deadline" type="date" required />
        <Button type="submit">{t('addGoal')}</Button>
      </form>
      <div className="space-y-4">
        {goals.map(goal => (
          <div key={goal.id} className="p-4 border rounded-lg">
            <h3 className="font-semibold">{goal.name}</h3>
            <Progress value={(goal.currentAmount / goal.targetAmount) * 100} />
            <p>{t('progress', { current: goal.currentAmount, target: goal.targetAmount })}</p>
            <p>{t('deadline', { date: new Date(goal.deadline).toLocaleDateString() })}</p>
            <Input
              type="number"
              placeholder={t('updateProgress')}
              onChange={(e) => updateGoalProgress(goal.id, Number(e.target.value))}
            />
          </div>
        ))}
      </div>
    </div>
  )
}

