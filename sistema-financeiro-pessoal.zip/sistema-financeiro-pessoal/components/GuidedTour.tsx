import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Steps } from 'intro.js-react'
import 'intro.js/minified/introjs.min.css'
import { useLanguage } from '@/contexts/LanguageContext'

export function GuidedTour() {
  const [showTour, setShowTour] = useState(false)
  const { data: session } = useSession()
  const { t } = useLanguage()

  useEffect(() => {
    if (session?.user?.isNewUser) {
      setShowTour(true)
    }
  }, [session])

  const steps = [
    {
      element: '#dashboard',
      intro: t('tourDashboardIntro'),
    },
    {
      element: '#transactions',
      intro: t('tourTransactionsIntro'),
    },
    {
      element: '#budget',
      intro: t('tourBudgetIntro'),
    },
    {
      element: '#goals',
      intro: t('tourGoalsIntro'),
    },
  ]

  const onExit = () => {
    setShowTour(false)
    // Marcar o usuário como não mais novo
    fetch('/api/user/complete-tour', { method: 'POST' })
  }

  return (
    <Steps
      enabled={showTour}
      steps={steps}
      initialStep={0}
      onExit={onExit}
    />
  )
}

