import React from 'react'
import { useLanguage } from '../contexts/LanguageContext'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

type OverviewData = {
  totalBalance: number
  monthlyIncome: number
  monthlyExpenses: number
  savingsGoalProgress: number
}

export function QuickOverviewWidget({ data }: { data: OverviewData }) {
  const { t } = useLanguage()

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('quickOverview')}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium">{t('totalBalance')}</p>
            <p className="text-2xl font-bold">
              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(data.totalBalance)}
            </p>
          </div>
          <div className="flex justify-between">
            <div>
              <p className="text-sm font-medium">{t('monthlyIncome')}</p>
              <p className="text-lg font-semibold text-green-600">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(data.monthlyIncome)}
              </p>
            </div>
            <div>
              <p className="text-sm font-medium">{t('monthlyExpenses')}</p>
              <p className="text-lg font-semibold text-red-600">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(data.monthlyExpenses)}
              </p>
            </div>
          </div>
          <div>
            <p className="text-sm font-medium">{t('savingsGoalProgress')}</p>
            <Progress value={data.savingsGoalProgress} className="mt-2" />
            <p className="text-sm text-right mt-1">{data.savingsGoalProgress}%</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

