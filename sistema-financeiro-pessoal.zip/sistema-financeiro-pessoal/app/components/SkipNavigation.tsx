import { useState } from 'react'

export function SkipNavigation() {
  const [isFocused, setIsFocused] = useState(false)

  return (
    <a
      href="#main-content"
      className={`
        sr-only focus:not-sr-only focus:absolute focus:top-0 focus:left-0 
        bg-blue-500 text-white p-2 z-50
        ${isFocused ? 'block' : ''}
      `}
      onFocus={() => setIsFocused(true)}
      onBlur={() => setIsFocused(false)}
    >
      Pular para o conteúdo principal
    </a>
  )
}

