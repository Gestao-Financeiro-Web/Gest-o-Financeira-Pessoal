'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

type Category = {
  id: string
  name: string
}

export function CategoryManager() {
  const [categories, setCategories] = useState<Category[]>([])
  const [newCategory, setNewCategory] = useState('')

  useEffect(() => {
    // In a real application, you would fetch this data from your API
    const mockCategories: Category[] = [
      { id: '1', name: 'Alimentação' },
      { id: '2', name: 'Transporte' },
      { id: '3', name: 'Lazer' },
      { id: '4', name: 'Saúde' },
    ]
    setCategories(mockCategories)
  }, [])

  const handleAddCategory = () => {
    if (newCategory.trim()) {
      const newCategoryItem: Category = {
        id: Date.now().toString(),
        name: newCategory.trim()
      }
      setCategories([...categories, newCategoryItem])
      setNewCategory('')
    }
  }

  const handleDeleteCategory = (id: string) => {
    setCategories(categories.filter(category => category.id !== id))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Gerenciar Categorias</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-4">
          <Input
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            placeholder="Nova categoria"
          />
          <Button onClick={handleAddCategory}>Adicionar</Button>
        </div>
        <ul className="space-y-2">
          {categories.map(category => (
            <li key={category.id} className="flex justify-between items-center">
              <span>{category.name}</span>
              <Button variant="destructive" size="sm" onClick={() => handleDeleteCategory(category.id)}>Excluir</Button>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

