import Link from 'next/link'
import Image from 'next/image'
import { useSession, signOut } from 'next-auth/react'
import { ThemeToggle } from './ThemeToggle'
import { Menu, Database } from 'lucide-react'
import { useState } from 'react'
import { LanguageSwitcher } from './LanguageSwitcher'
import { useLanguage } from '../contexts/LanguageContext'

function Header() {
  const { data: session } = useSession()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { t } = useLanguage()

  return (
    <header className="bg-white dark:bg-gray-800 shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <Image
            src="/logo.webp"
            alt="Sistema Financeiro Pessoal Logo"
            width={40}
            height={40}
            className="mr-2"
          />
          <span className="text-xl font-bold text-gray-800 dark:text-white">
            Sistema Financeiro Pessoal
          </span>
        </Link>
        <div className="hidden md:flex items-center space-x-4">
          {session ? (
            <>
              <Link href="/dashboard" className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                {t('dashboard')}
              </Link>
              <Link href="/transacoes" className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                {t('transactions')}
              </Link>
              <Link href="/metas" className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                {t('goals')}
              </Link>
              <Link href="/backup" className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                <Database className="inline-block mr-1" size={18} />
                {t('backup')}
              </Link>
              <button onClick={() => signOut()} className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                {t('logout')}
              </button>
            </>
          ) : (
            <Link href="/login" className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
              {t('login')}
            </Link>
          )}
          <LanguageSwitcher />
          <ThemeToggle />
        </div>
        <div className="md:hidden">
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-600 dark:text-gray-300">
            <Menu size={24} />
          </button>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden bg-white dark:bg-gray-800 py-2">
          {session ? (
            <>
              <Link href="/dashboard" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                {t('dashboard')}
              </Link>
              <Link href="/transacoes" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                {t('transactions')}
              </Link>
              <Link href="/metas" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                {t('goals')}
              </Link>
              <Link href="/backup" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                <Database className="inline-block mr-1" size={18} />
                {t('backup')}
              </Link>
              <button onClick={() => signOut()} className="block w-full text-left px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                {t('logout')}
              </button>
            </>
          ) : (
            <Link href="/login" className="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
              {t('login')}
            </Link>
          )}
          <div className="px-4 py-2">
            <ThemeToggle />
          </div>
        </div>
      )}
    </header>
  )
}

export default Header

