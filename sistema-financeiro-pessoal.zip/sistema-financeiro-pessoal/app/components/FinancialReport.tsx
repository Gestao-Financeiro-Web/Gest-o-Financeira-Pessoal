'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Pie } from 'react-chartjs-2'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'

ChartJS.register(ArcElement, Tooltip, Legend)

type Transaction = {
  id: string
  amount: number
  category: string
  type: 'income' | 'expense'
}

export function FinancialReport() {
  const [transactions, setTransactions] = useState<Transaction[]>([])

  useEffect(() => {
    // In a real application, you would fetch this data from your API
    const mockTransactions: Transaction[] = [
      { id: '1', amount: 1000, category: 'Salário', type: 'income' },
      { id: '2', amount: 200, category: 'Alimentação', type: 'expense' },
      { id: '3', amount: 150, category: 'Transporte', type: 'expense' },
      { id: '4', amount: 300, category: 'Lazer', type: 'expense' },
      { id: '5', amount: 200, category: 'Freelance', type: 'income' },
    ]
    setTransactions(mockTransactions)
  }, [])

  const incomeData = transactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0)
  const expenseData = transactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0)

  const pieData = {
    labels: ['Receitas', 'Despesas'],
    datasets: [
      {
        data: [incomeData, expenseData],
        backgroundColor: ['rgba(75, 192, 192, 0.6)', 'rgba(255, 99, 132, 0.6)'],
        borderColor: ['rgba(75, 192, 192, 1)', 'rgba(255, 99, 132, 1)'],
        borderWidth: 1,
      },
    ],
  }

  const expensesByCategory = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount
      return acc
    }, {} as Record<string, number>)

  const expensePieData = {
    labels: Object.keys(expensesByCategory),
    datasets: [
      {
        data: Object.values(expensesByCategory),
        backgroundColor: [
          'rgba(255, 99, 132, 0.6)',
          'rgba(54, 162, 235, 0.6)',
          'rgba(255, 206, 86, 0.6)',
          'rgba(75, 192, 192, 0.6)',
          'rgba(153, 102, 255, 0.6)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
        ],
        borderWidth: 1,
      },
    ],
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Visão Geral</CardTitle>
        </CardHeader>
        <CardContent>
          <Pie data={pieData} />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Despesas por Categoria</CardTitle>
        </CardHeader>
        <CardContent>
          <Pie data={expensePieData} />
        </CardContent>
      </Card>
    </div>
  )
}

