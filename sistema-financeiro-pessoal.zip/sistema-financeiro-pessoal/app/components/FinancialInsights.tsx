'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowUpIcon, ArrowDownIcon } from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'
import { cachedFetch } from '../utils/api-cache'

type Insight = {
  title: string
  value: number
  previousValue: number
  target?: number
}

export function FinancialInsights() {
  const [insights, setInsights] = useState<Insight[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { t } = useLanguage()

  useEffect(() => {
    fetchInsights()
  }, [])

  const fetchInsights = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const data = await cachedFetch('/api/insights', {}, 300000) // 5 minutes cache
      setInsights(data)
    } catch (error) {
      console.error('Error fetching insights:', error)
      setError(t('errorFetchingInsights'))
    } finally {
      setIsLoading(false)
    }
  }

  const calculatePercentageChange = (current: number, previous: number) => {
    return ((current - previous) / previous) * 100
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)
  }

  if (isLoading) {
    return <div>{t('loadingInsights')}</div>
  }

  if (error) {
    return <div className="text-red-500">{error}</div>
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {insights.map((insight, index) => (
        <Card key={index}>
          <CardHeader>
            <CardTitle className="text-sm font-medium">{t(insight.title)}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(insight.value)}</div>
            <div className="flex items-center mt-2">
              {insight.value > insight.previousValue ? (
                <ArrowUpIcon className="w-4 h-4 text-green-500 mr-1" />
              ) : (
                <ArrowDownIcon className="w-4 h-4 text-red-500 mr-1" />
              )}
              <span className={insight.value > insight.previousValue ? "text-green-500" : "text-red-500"}>
                {Math.abs(calculatePercentageChange(insight.value, insight.previousValue)).toFixed(1)}%
              </span>
              <span className="text-gray-500 ml-1">{t('vsPreviousMonth')}</span>
            </div>
            {insight.target !== undefined && (
              <div className="mt-4">
                <div className="flex justify-between text-sm mb-1">
                  <span>{t('progress')}</span>
                  <span>{((insight.value / insight.target) * 100).toFixed(0)}%</span>
                </div>
                <Progress value={(insight.value / insight.target) * 100} />
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

