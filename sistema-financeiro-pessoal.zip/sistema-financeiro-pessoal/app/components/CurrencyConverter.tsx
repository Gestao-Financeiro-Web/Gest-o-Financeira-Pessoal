'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const currencies = ['BRL', 'USD', 'EUR', 'GBP', 'JPY']

export function CurrencyConverter() {
  const [amount, setAmount] = useState('')
  const [fromCurrency, setFromCurrency] = useState('BRL')
  const [toCurrency, setToCurrency] = useState('USD')
  const [result, setResult] = useState<number | null>(null)

  const handleConvert = async () => {
    // In a real application, you would call an API here
    // For this example, we'll use a mock conversion rate
    const mockRates = {
      BRL: 1,
      USD: 0.2,
      EUR: 0.18,
      GBP: 0.16,
      JPY: 29.5
    }

    const convertedAmount = parseFloat(amount) * (mockRates[toCurrency as keyof typeof mockRates] / mockRates[fromCurrency as keyof typeof mockRates])
    setResult(convertedAmount)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Conversor de Moedas</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="amount">Valor</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Digite o valor"
              />
            </div>
            <div>
              <Label htmlFor="fromCurrency">De</Label>
              <Select value={fromCurrency} onValueChange={setFromCurrency}>
                <SelectTrigger id="fromCurrency">
                  <SelectValue placeholder="Selecione a moeda" />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency} value={currency}>{currency}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="toCurrency">Para</Label>
              <Select value={toCurrency} onValueChange={setToCurrency}>
                <SelectTrigger id="toCurrency">
                  <SelectValue placeholder="Selecione a moeda" />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency} value={currency}>{currency}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <button onClick={handleConvert} className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition-colors">
            Converter
          </button>
          {result !== null && (
            <div className="mt-4">
              <p className="font-bold">Resultado:</p>
              <p>{amount} {fromCurrency} = {result.toFixed(2)} {toCurrency}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

