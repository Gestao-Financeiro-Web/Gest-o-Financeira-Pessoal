'use client'

import { useLanguage } from '../contexts/LanguageContext'
import { Button } from "@/components/ui/button"

export function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage()

  return (
    <Button
      onClick={() => setLanguage(language === 'en' ? 'pt-BR' : 'en')}
      variant="outline"
      size="sm"
    >
      {language === 'en' ? 'PT' : 'EN'}
    </Button>
  )
}

