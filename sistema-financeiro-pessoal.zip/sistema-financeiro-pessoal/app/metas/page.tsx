'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Header from '../components/Header'
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

type Goal = {
  id: string
  name: string
  targetAmount: number
  currentAmount: number
  deadline: string
}

export default function Metas() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [goals, setGoals] = useState<Goal[]>([])
  const [newGoal, setNewGoal] = useState({
    name: '',
    targetAmount: '',
    currentAmount: '',
    deadline: ''
  })

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login')
    } else if (status === 'authenticated') {
      // Fetch goals
      // This is a mock fetch, replace with actual API call
      setGoals([
        { id: '1', name: 'Férias', targetAmount: 5000, currentAmount: 2000, deadline: '2024-07-01' },
        { id: '2', name: 'Novo Carro', targetAmount: 30000, currentAmount: 10000, deadline: '2025-01-01' },
      ])
    }
  }, [status, router])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewGoal({ ...newGoal, [e.target.name]: e.target.value })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Add new goal
    // This is a mock addition, replace with actual API call
    const newGoalItem: Goal = {
      id: Date.now().toString(),
      name: newGoal.name,
      targetAmount: parseFloat(newGoal.targetAmount),
      currentAmount: parseFloat(newGoal.currentAmount),
      deadline: newGoal.deadline
    }
    setGoals([...goals, newGoalItem])
    setNewGoal({ name: '', targetAmount: '', currentAmount: '', deadline: '' })
  }

  if (status === 'loading') {
    return <div>Carregando...</div>
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto mt-10 px-4">
        <h1 className="text-3xl font-bold mb-6">Metas Financeiras</h1>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="mb-4">Adicionar Meta</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Adicionar Meta</DialogTitle>
              <DialogDescription>
                Defina uma nova meta financeira aqui.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Nome
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    value={newGoal.name}
                    onChange={handleInputChange}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="targetAmount" className="text-right">
                    Valor Alvo
                  </Label>
                  <Input
                    id="targetAmount"
                    name="targetAmount"
                    type="number"
                    value={newGoal.targetAmount}
                    onChange={handleInputChange}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="currentAmount" className="text-right">
                    Valor Atual
                  </Label>
                  <Input
                    id="currentAmount"
                    name="currentAmount"
                    type="number"
                    value={newGoal.currentAmount}
                    onChange={handleInputChange}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="deadline" className="text-right">
                    Prazo
                  </Label>
                  <Input
                    id="deadline"
                    name="deadline"
                    type="date"
                    value={newGoal.deadline}
                    onChange={handleInputChange}
                    className="col-span-3"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Salvar Meta</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goals.map((goal) => (
            <Card key={goal.id}>
              <CardHeader>
                <CardTitle>{goal.name}</CardTitle>
                <CardDescription>Meta: R$ {goal.targetAmount.toFixed(2)}</CardDescription>
              </CardHeader>
              <CardContent>
                <Progress value={(goal.currentAmount / goal.targetAmount) * 100} className="w-full" />
                <p className="mt-2">R$ {goal.currentAmount.toFixed(2)} / R$ {goal.targetAmount.toFixed(2)}</p>
              </CardContent>
              <CardFooter>
                <p>Prazo: {new Date(goal.deadline).toLocaleDateString()}</p>
              </CardFooter>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}

