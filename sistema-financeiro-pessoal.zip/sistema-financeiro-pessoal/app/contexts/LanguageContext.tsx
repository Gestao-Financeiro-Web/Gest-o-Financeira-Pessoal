'use client'

import React, { createContext, useState, useContext } from 'react'

type Language = 'en' | 'pt-BR'

type Translations = {
  [key: string]: {
    [key: string]: string
  }
}

const translations: Translations = {
  en: {
    dashboard: 'Dashboard',
    transactions: 'Transactions',
    goals: 'Goals',
    budget: 'Budget',
    backup: 'Backup',
    logout: 'Logout',
    login: 'Login',
    currentBalance: 'Current Balance',
    exchangeRates: 'Exchange Rates',
    dateAndTime: 'Date and Time',
    incomeAndExpenses: 'Income and Expenses',
    addNewTransaction: 'Add New Transaction',
    amount: 'Amount',
    description: 'Description',
    category: 'Category',
    type: 'Type',
    expense: 'Expense',
    income: 'Income',
    addTransaction: 'Add Transaction',
    transactionList: 'Transaction List',
    date: 'Date',
    value: 'Value',
    totalExpenses: 'Total Expenses',
    savings: 'Savings',
    totalIncome: 'Total Income',
    balance: 'Balance',
    vsPreviousMonth: 'vs. previous month',
    progress: 'Progress',
    loading: 'Loading...',
    errorFetchingDashboard: 'Error fetching dashboard data. Please try again.',
    errorFetchingInsights: 'Error fetching financial insights. Please try again.',
    loadingInsights: 'Loading financial insights...',
  },
  'pt-BR': {
    dashboard: 'Painel',
    transactions: 'Transações',
    goals: 'Metas',
    budget: 'Orçamento',
    backup: 'Backup',
    logout: 'Sair',
    login: 'Entrar',
    currentBalance: 'Saldo Atual',
    exchangeRates: 'Taxas de Câmbio',
    dateAndTime: 'Data e Hora',
    incomeAndExpenses: 'Receitas e Despesas',
    addNewTransaction: 'Adicionar Nova Transação',
    amount: 'Valor',
    description: 'Descrição',
    category: 'Categoria',
    type: 'Tipo',
    expense: 'Despesa',
    income: 'Receita',
    addTransaction: 'Adicionar Transação',
    transactionList: 'Lista de Transações',
    date: 'Data',
    value: 'Valor',
    totalExpenses: 'Despesas Totais',
    savings: 'Economia',
    totalIncome: 'Renda Total',
    balance: 'Saldo',
    vsPreviousMonth: 'vs. mês anterior',
    progress: 'Progresso',
    loading: 'Carregando...',
    errorFetchingDashboard: 'Erro ao carregar dados do painel. Por favor, tente novamente.',
    errorFetchingInsights: 'Erro ao carregar insights financeiros. Por favor, tente novamente.',
    loadingInsights: 'Carregando insights financeiros...',
  },
}

type LanguageContextType = {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('pt-BR')

  const t = (key: string) => {
    return translations[language][key] || key
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}

