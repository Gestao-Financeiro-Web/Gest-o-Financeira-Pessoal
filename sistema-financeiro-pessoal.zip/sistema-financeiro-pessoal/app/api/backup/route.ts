import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  try {
    const userId = session.user.id
    const transactions = await prisma.transaction.findMany({ where: { userId } })
    const goals = await prisma.goal.findMany({ where: { userId } })

    const backupData = {
      transactions,
      goals,
      timestamp: new Date().toISOString()
    }

    return NextResponse.json(backupData)
  } catch (error) {
    console.error('Erro ao criar backup:', error)
    return NextResponse.json({ error: 'Erro ao criar backup' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  try {
    const userId = session.user.id
    const backupData = await request.json()

    // Limpar dados existentes
    await prisma.transaction.deleteMany({ where: { userId } })
    await prisma.goal.deleteMany({ where: { userId } })

    // Restaurar transações
    await prisma.transaction.createMany({
      data: backupData.transactions.map((t: any) => ({ ...t, userId }))
    })

    // Restaurar metas
    await prisma.goal.createMany({
      data: backupData.goals.map((g: any) => ({ ...g, userId }))
    })

    return NextResponse.json({ message: 'Backup restaurado com sucesso' })
  } catch (error) {
    console.error('Erro ao restaurar backup:', error)
    return NextResponse.json({ error: 'Erro ao restaurar backup' }, { status: 500 })
  }
}

