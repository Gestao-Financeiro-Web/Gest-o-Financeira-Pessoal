import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { logInfo, logError } from '@/app/utils/logger'

export async function GET() {
  const session = await getServerSession()
  if (!session) {
    logWarn(`Unauthorized access attempt to dashboard API`)
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  try {
    logInfo(`Fetching dashboard data for user ${session.user.id}`)
    const userId = session.user.id

    // ... (rest of the function remains the same)

    logInfo(`Successfully fetched dashboard data for user ${userId}`)
    return NextResponse.json({
      balance,
      chartLabels: months,
      incomeData,
      expenseData
    })
  } catch (error) {
    logError(`Error fetching dashboard data: ${error}`)
    return NextResponse.json({ error: 'Erro ao buscar dados do dashboard' }, { status: 500 })
  }
}

