import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  try {
    const userId = session.user.id

    const currentMonth = new Date()
    const previousMonth = new Date(currentMonth)
    previousMonth.setMonth(previousMonth.getMonth() - 1)

    const currentMonthTransactions = await prisma.transaction.findMany({
      where: {
        userId,
        date: {
          gte: new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1),
          lt: new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1),
        },
      },
    })

    const previousMonthTransactions = await prisma.transaction.findMany({
      where: {
        userId,
        date: {
          gte: new Date(previousMonth.getFullYear(), previousMonth.getMonth(), 1),
          lt: new Date(previousMonth.getFullYear(), previousMonth.getMonth() + 1, 1),
        },
      },
    })

    const calculateTotal = (transactions: any[], type: 'income' | 'expense') =>
      transactions
        .filter(t => t.type === type)
        .reduce((sum, t) => sum + t.amount, 0)

    const currentIncome = calculateTotal(currentMonthTransactions, 'income')
    const currentExpenses = calculateTotal(currentMonthTransactions, 'expense')
    const previousIncome = calculateTotal(previousMonthTransactions, 'income')
    const previousExpenses = calculateTotal(previousMonthTransactions, 'expense')

    const savings = currentIncome - currentExpenses
    const previousSavings = previousIncome - previousExpenses

    const insights = [
      {
        title: 'totalExpenses',
        value: currentExpenses,
        previousValue: previousExpenses,
        target: currentIncome * 0.7, // Example: target is 70% of income
      },
      {
        title: 'savings',
        value: savings,
        previousValue: previousSavings,
        target: currentIncome * 0.3, // Example: target is 30% of income
      },
      {
        title: 'totalIncome',
        value: currentIncome,
        previousValue: previousIncome,
      },
      {
        title: 'balance',
        value: currentIncome - currentExpenses,
        previousValue: previousIncome - previousExpenses,
      },
    ]

    return NextResponse.json(insights)
  } catch (error) {
    console.error('Error fetching financial insights:', error)
    return NextResponse.json({ error: 'Erro ao buscar insights financeiros' }, { status: 500 })
  }
}

