import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { z } from 'zod'

const budgetCategorySchema = z.object({
  name: z.string().min(1),
  budgeted: z.number().positive()
})

export async function GET() {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  try {
    const categories = await prisma.budgetCategory.findMany({
      where: { userId: session.user.id }
    })
    return NextResponse.json(categories)
  } catch (error) {
    console.error('Error fetching budget categories:', error)
    return NextResponse.json({ error: 'Erro ao buscar categorias de orçamento' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  try {
    const json = await request.json()
    const body = budgetCategorySchema.parse(json)

    const category = await prisma.budgetCategory.create({
      data: {
        ...body,
        userId: session.user.id
      }
    })

    return NextResponse.json(category)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }
    console.error('Error creating budget category:', error)
    return NextResponse.json({ error: 'Erro ao criar categoria de orçamento' }, { status: 500 })
  }
}

