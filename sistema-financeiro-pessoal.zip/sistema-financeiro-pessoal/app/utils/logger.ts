enum LogLevel {
  INFO,
  WARN,
  ERROR
}

export function log(message: string, level: LogLevel = LogLevel.INFO) {
  const timestamp = new Date().toISOString()
  const logMessage = `[${timestamp}] ${LogLevel[level]}: ${message}`

  switch (level) {
    case LogLevel.INFO:
      console.log(logMessage)
      break
    case LogLevel.WARN:
      console.warn(logMessage)
      break
    case LogLevel.ERROR:
      console.error(logMessage)
      break
  }

  // In a production environment, you might want to send logs to a service like Logstash or CloudWatch
}

export const logInfo = (message: string) => log(message, LogLevel.INFO)
export const logWarn = (message: string) => log(message, LogLevel.WARN)
export const logError = (message: string) => log(message, LogLevel.ERROR)

