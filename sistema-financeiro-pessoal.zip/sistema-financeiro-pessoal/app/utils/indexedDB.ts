import { openDB, DBSchema, IDBPDatabase } from 'idb'

interface MyDB extends DBSchema {
  transactions: {
    key: string
    value: {
      id: string
      amount: number
      description: string
      category: string
      date: string
      type: 'expense' | 'income'
      synced: boolean
    }
  }
  goals: {
    key: string
    value: {
      id: string
      name: string
      targetAmount: number
      currentAmount: number
      deadline: string
      synced: boolean
    }
  }
}

let db: IDBPDatabase<MyDB>

export async function initDB() {
  db = await openDB<MyDB>('FinanceDB', 1, {
    upgrade(db) {
      db.createObjectStore('transactions', { keyPath: 'id' })
      db.createObjectStore('goals', { keyPath: 'id' })
    },
  })
}

export async function addTransaction(transaction: MyDB['transactions']['value']) {
  if (!db) await initDB()
  return db.add('transactions', { ...transaction, synced: false })
}

export async function addGoal(goal: MyDB['goals']['value']) {
  if (!db) await initDB()
  return db.add('goals', { ...goal, synced: false })
}

export async function getUnsynced() {
  if (!db) await initDB()
  const unsyncedTransactions = await db.getAllFromIndex('transactions', 'synced', false)
  const unsyncedGoals = await db.getAllFromIndex('goals', 'synced', false)
  return { transactions: unsyncedTransactions, goals: unsyncedGoals }
}

export async function markSynced(storeName: 'transactions' | 'goals', id: string) {
  if (!db) await initDB()
  const tx = await db.transaction(storeName, 'readwrite')
  const store = tx.objectStore(storeName)
  const item = await store.get(id)
  if (item) {
    item.synced = true
    await store.put(item)
  }
  await tx.done
}

