import { openDB } from 'idb'
import { AES, enc } from 'crypto-js'

const ENCRYPTION_KEY = process.env.NEXT_PUBLIC_BACKUP_ENCRYPTION_KEY || 'default-key'

export async function backupData() {
  const db = await openDB('FinanceDB', 1)
  const transactions = await db.getAll('transactions')
  const goals = await db.getAll('goals')
  
  const backupData = {
    transactions,
    goals,
    timestamp: new Date().toISOString()
  }

  const encryptedData = AES.encrypt(JSON.stringify(backupData), ENCRYPTION_KEY).toString()

  return new Blob([encryptedData], { type: 'application/octet-stream' })
}

export async function restoreData(encryptedBackupData: string) {
  try {
    const decryptedData = AES.decrypt(encryptedBackupData, ENCRYPTION_KEY).toString(enc.Utf8)
    const backupData = JSON.parse(decryptedData)

    if (!isValidBackupData(backupData)) {
      throw new Error('Invalid backup data')
    }

    const db = await openDB('FinanceDB', 1)
    const tx = db.transaction(['transactions', 'goals'], 'readwrite')

    // Clear existing data
    await tx.objectStore('transactions').clear()
    await tx.objectStore('goals').clear()

    // Restore transactions
    for (const transaction of backupData.transactions) {
      await tx.objectStore('transactions').add(transaction)
    }

    // Restore goals
    for (const goal of backupData.goals) {
      await tx.objectStore('goals').add(goal)
    }

    await tx.done
  } catch (error) {
    console.error('Error restoring data:', error)
    throw new Error('Failed to restore backup')
  }
}

function isValidBackupData(data: any): boolean {
  return (
    data &&
    Array.isArray(data.transactions) &&
    Array.isArray(data.goals) &&
    typeof data.timestamp === 'string'
  )
}

export async function* backupDataGenerator() {
  const db = await openDB('FinanceDB', 1)
  const transactionCursor = await db.transaction('transactions').store.openCursor()
  const goalCursor = await db.transaction('goals').store.openCursor()

  const backupData = {
    transactions: [],
    goals: [],
    timestamp: new Date().toISOString()
  }

  while (transactionCursor) {
    backupData.transactions.push(transactionCursor.value)
    yield
    await transactionCursor.continue()
  }

  while (goalCursor) {
    backupData.goals.push(goalCursor.value)
    yield
    await goalCursor.continue()
  }

  const encryptedData = AES.encrypt(JSON.stringify(backupData), ENCRYPTION_KEY).toString()
  return new Blob([encryptedData], { type: 'application/octet-stream' })
}

