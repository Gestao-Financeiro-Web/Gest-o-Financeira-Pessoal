const performanceMetrics: { [key: string]: number[] } = {}

export function startMeasure(name: string) {
  if (typeof performance !== 'undefined') {
    performance.mark(`${name}-start`)
  }
}

export function endMeasure(name: string) {
  if (typeof performance !== 'undefined') {
    performance.mark(`${name}-end`)
    performance.measure(name, `${name}-start`, `${name}-end`)
    
    const entries = performance.getEntriesByName(name)
    const latestEntry = entries[entries.length - 1]
    
    if (!performanceMetrics[name]) {
      performanceMetrics[name] = []
    }
    performanceMetrics[name].push(latestEntry.duration)

    // Keep only the last 100 measurements
    if (performanceMetrics[name].length > 100) {
      performanceMetrics[name].shift()
    }

    // Log the average performance
    const average = performanceMetrics[name].reduce((a, b) => a + b, 0) / performanceMetrics[name].length
    console.log(`Average ${name} duration: ${average.toFixed(2)}ms`)
  }
}

