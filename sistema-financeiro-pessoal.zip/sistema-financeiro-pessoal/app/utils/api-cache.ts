type CacheItem<T> = {
  data: T;
  expiry: number;
}

const cache: { [key: string]: CacheItem<any> } = {};

export async function cachedFetch<T>(url: string, options: RequestInit = {}, ttl = 60000): Promise<T> {
  const cacheKey = `${url}${JSON.stringify(options)}`;
  const now = Date.now();

  if (cache[cacheKey] && cache[cacheKey].expiry > now) {
    return cache[cacheKey].data;
  }

  const response = await fetch(url, options);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  const data = await response.json();

  cache[cacheKey] = {
    data,
    expiry: now + ttl
  };

  return data;
}

