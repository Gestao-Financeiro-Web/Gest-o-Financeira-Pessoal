'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Header from '../components/Header'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useNotification } from '../contexts/NotificationContext'
import { backupData, restoreData, backupDataGenerator } from '../utils/backupUtils'

export default function BackupPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { addNotification } = useNotification()
  const [isBackingUp, setIsBackingUp] = useState(false)
  const [isRestoring, setIsRestoring] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [progress, setProgress] = useState(0)

  if (status === 'unauthenticated') {
    router.push('/login')
    return null
  }

  const handleBackup = async () => {
    setIsBackingUp(true)
    setProgress(0)
    try {
      const generator = backupDataGenerator()
      let result = await generator.next()
      let count = 0

      while (!result.done) {
        count++
        setProgress(Math.min(99, count))
        result = await generator.next()
      }

      const backupBlob = result.value
      const url = URL.createObjectURL(backupBlob)
      const a = document.createElement('a')
      a.href = url
      a.download = `finance_backup_${new Date().toISOString().split('T')[0]}.enc`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      setProgress(100)
      addNotification('Backup criado com sucesso!', 'success')
    } catch (error) {
      console.error('Erro ao criar backup:', error)
      addNotification('Erro ao criar backup. Tente novamente.', 'error')
    } finally {
      setIsBackingUp(false)
    }
  }

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setSelectedFile(event.target.files[0])
    }
  }

  const handleRestore = async () => {
    if (!selectedFile) {
      addNotification('Por favor, selecione um arquivo de backup.', 'warning')
      return
    }

    setIsRestoring(true)
    setProgress(0)
    try {
      const fileContent = await selectedFile.text()
      await restoreData(fileContent)
      setProgress(100)
      addNotification('Dados restaurados com sucesso!', 'success')
      router.push('/dashboard')
    } catch (error) {
      console.error('Erro ao restaurar dados:', error)
      addNotification('Erro ao restaurar dados. Verifique o arquivo e tente novamente.', 'error')
    } finally {
      setIsRestoring(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-10 px-4">
        <h1 className="text-3xl font-bold mb-6">Backup e Restauração</h1>
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Criar Backup</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Faça um backup dos seus dados para manter suas informações seguras.</p>
              <Button onClick={handleBackup} disabled={isBackingUp}>
                {isBackingUp ? 'Criando Backup...' : 'Criar Backup'}
              </Button>
              {isBackingUp && (
                <Progress value={progress} className="mt-4" />
              )}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Restaurar Backup</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Restaure seus dados a partir de um arquivo de backup.</p>
              <input
                type="file"
                accept=".enc"
                onChange={handleFileChange}
                className="mb-4 block w-full text-sm text-gray-500
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-full file:border-0
                  file:text-sm file:font-semibold
                  file:bg-violet-50 file:text-violet-700
                  hover:file:bg-violet-100"
              />
              <Button onClick={handleRestore} disabled={isRestoring || !selectedFile}>
                {isRestoring ? 'Restaurando...' : 'Restaurar Backup'}
              </Button>
              {isRestoring && (
                <Progress value={progress} className="mt-4" />
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

