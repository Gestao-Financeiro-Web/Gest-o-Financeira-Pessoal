import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { Redis } from '@upstash/redis'

const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
})

const RATE_LIMIT_REQUESTS = 100 // Number of requests
const RATE_LIMIT_WINDOW = 60 * 60 // 1 hour in seconds

export async function rateLimit(request: NextRequest) {
  const ip = request.ip ?? '127.0.0.1'
  const key = `rate_limit:${ip}`

  const current = await redis.get(key) as number | null
  if (current && current >= RATE_LIMIT_REQUESTS) {
    return NextResponse.json({ error: 'Too many requests' }, { status: 429 })
  }

  if (!current) {
    await redis.set(key, 1, { ex: RATE_LIMIT_WINDOW })
  } else {
    await redis.incr(key)
  }

  return NextResponse.next()
}

