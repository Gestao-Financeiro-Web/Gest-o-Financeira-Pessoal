import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { rateLimit } from './middleware/rateLimit'

export async function middleware(request: NextRequest) {
  if (request.nextUrl.pathname.startsWith('/api/')) {
    return await rateLimit(request)
  }

  return NextResponse.next()
}

