import Header from './components/Header'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto mt-10 px-4">
        <h1 className="text-4xl font-bold mb-6">Bem-vindo ao Sistema Financeiro Pessoal</h1>
        <p className="mb-4">Gerencie suas finanças de forma eficiente e alcance seus objetivos financeiros.</p>
        <Link href="/login" className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition-colors">
          Começar
        </Link>
      </main>
    </div>
  )
}

