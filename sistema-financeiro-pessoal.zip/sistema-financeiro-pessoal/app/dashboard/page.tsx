'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Header from '../components/Header'
import { FinancialInsights } from '../components/FinancialInsights'
import { CurrencyConverter } from '../components/CurrencyConverter'
import { FinancialReport } from '../components/FinancialReport'
import { useLanguage } from '../contexts/LanguageContext'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'
import { startMeasure, endMeasure } from '../utils/performance'
import { cachedFetch } from '../utils/api-cache'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

export default function Dashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { t } = useLanguage()
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [dashboardData, setDashboardData] = useState<any>(null)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login')
    } else if (status === 'authenticated') {
      fetchDashboardData()
    }
  }, [status, router])

  const fetchDashboardData = async () => {
    setIsLoading(true)
    setError(null)
    startMeasure('fetchDashboardData')
    try {
      const data = await cachedFetch('/api/dashboard', {}, 300000) // 5 minutes cache
      setDashboardData(data)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
      setError(t('errorFetchingDashboard'))
    } finally {
      setIsLoading(false)
      endMeasure('fetchDashboardData')
    }
  }

  if (status === 'loading' || isLoading) {
    return <div className="flex justify-center items-center h-screen">{t('loading')}</div>
  }

  if (error) {
    return <div className="text-red-500 text-center mt-10">{error}</div>
  }

  const chartData = {
    labels: dashboardData?.chartLabels || [],
    datasets: [
      {
        label: t('income'),
        data: dashboardData?.incomeData || [],
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
      {
        label: t('expenses'),
        data: dashboardData?.expenseData || [],
        backgroundColor: 'rgba(255, 99, 132, 0.6)',
      },
    ],
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-10 px-4">
        <h1 className="text-3xl font-bold mb-6">{t('dashboard')}</h1>
        <FinancialInsights />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('incomeAndExpenses')}</CardTitle>
            </CardHeader>
            <CardContent>
              <Bar data={chartData} />
            </CardContent>
          </Card>
          <CurrencyConverter />
        </div>
        <div className="mt-6">
          <FinancialReport />
        </div>
      </main>
    </div>
  )
}

