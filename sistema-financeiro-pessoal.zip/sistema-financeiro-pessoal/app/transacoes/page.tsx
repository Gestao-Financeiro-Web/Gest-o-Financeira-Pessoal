'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Header from '../components/Header'
import { useNotification } from '../contexts/NotificationContext'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useLanguage } from '../contexts/LanguageContext'

interface Transaction {
  id: string
  amount: number
  description: string
  category: string
  date: string
  type: 'expense' | 'income'
}

export default function TransacoesPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { addNotification } = useNotification()
  const { t } = useLanguage()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [newTransaction, setNewTransaction] = useState<Omit<Transaction, 'id' | 'date'>>({
    amount: 0,
    description: '',
    category: '',
    type: 'expense'
  })
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login')
    } else if (status === 'authenticated') {
      fetchTransactions()
    }
  }, [status, router])

  const fetchTransactions = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/transactions')
      if (!response.ok) {
        throw new Error('Falha ao buscar transações')
      }
      const data = await response.json()
      setTransactions(data)
    } catch (error) {
      console.error('Error fetching transactions:', error)
      setError('Erro ao carregar transações. Por favor, tente novamente.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setNewTransaction(prev => ({ ...prev, [name]: name === 'amount' ? parseFloat(value) : value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/transactions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newTransaction,
          date: new Date().toISOString().split('T')[0]
        }),
      })

      if (!response.ok) {
        throw new Error('Falha ao adicionar transação')
      }

      const addedTransaction = await response.json()
      setTransactions(prev => [addedTransaction, ...prev])
      setNewTransaction({ amount: 0, description: '', category: '', type: 'expense' })
      addNotification('Transação adicionada com sucesso!', 'success')
    } catch (error) {
      console.error('Error adding transaction:', error)
      addNotification('Erro ao adicionar transação. Por favor, tente novamente.', 'error')
    }
  }

  if (status === 'loading' || isLoading) {
    return <div>Carregando...</div>
  }

  if (error) {
    return <div className="text-red-500">{error}</div>
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-10 px-4">
        <h1 className="text-3xl font-bold mb-6">{t('transactions')}</h1>
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>{t('addNewTransaction')}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="amount" className="block text-sm font-medium text-gray-700">{t('amount')}</label>
                  <Input
                    type="number"
                    id="amount"
                    name="amount"
                    value={newTransaction.amount}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700">{t('description')}</label>
                  <Input
                    type="text"
                    id="description"
                    name="description"
                    value={newTransaction.description}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700">{t('category')}</label>
                  <Input
                    type="text"
                    id="category"
                    name="category"
                    value={newTransaction.category}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="type" className="block text-sm font-medium text-gray-700">{t('type')}</label>
                  <Select
                    id="type"
                    name="type"
                    value={newTransaction.type}
                    onValueChange={(value) => setNewTransaction(prev => ({ ...prev, type: value as 'expense' | 'income' }))}
                  >
                    <Select.Trigger className="w-full">
                      <Select.Value placeholder="Selecione o tipo" />
                    </Select.Trigger>
                    <Select.Content>
                      <Select.Item value="expense">{t('expense')}</Select.Item>
                      <Select.Item value="income">{t('income')}</Select.Item>
                    </Select.Content>
                  </Select>
                </div>
              </div>
              <Button type="submit" className="w-full">{t('addTransaction')}</Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>{t('transactionList')}</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('date')}</TableHead>
                  <TableHead>{t('description')}</TableHead>
                  <TableHead>{t('category')}</TableHead>
                  <TableHead>{t('value')}</TableHead>
                  <TableHead>{t('type')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>{new Date(transaction.date).toLocaleDateString()}</TableCell>
                    <TableCell>{transaction.description}</TableCell>
                    <TableCell>{transaction.category}</TableCell>
                    <TableCell>R$ {transaction.amount.toFixed(2)}</TableCell>
                    <TableCell>{transaction.type === 'expense' ? t('expense') : t('income')}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

