import { Transaction } from '@prisma/client'

const categoryKeywords: { [key: string]: string[] } = {
  'Alimentação': ['restaurante', 'supermercado', 'mercado', 'lanchonete'],
  'Transporte': ['uber', '99', 'taxi', 'ônibus', 'metrô', 'combustível'],
  'Moradia': ['aluguel', 'condomínio', 'luz', 'água', 'gás'],
  'Saúde': ['farmácia', 'hospital', 'médico', 'dentista'],
  'Lazer': ['cinema', 'teatro', 'show', 'viagem'],
  'Educação': ['escola', 'faculdade', 'curso', 'livro'],
}

export function autoCategorizeTx(transaction: Omit<Transaction, 'id' | 'userId' | 'createdAt' | 'updatedAt'>): string {
  const description = transaction.description.toLowerCase()
  
  for (const [category, keywords] of Object.entries(categoryKeywords)) {
    if (keywords.some(keyword => description.includes(keyword))) {
      return category
    }
  }
  
  return 'Outros'
}

