# Guia de Instalação - Sistema Financeiro Pessoal

[... conteúdo anterior ...]

## 13. Configuração de SSL com Cloudflare e Acesso Específico

### 13.1 Obter Certificado SSL do Cloudflare

1. Crie uma conta no Cloudflare (https://dash.cloudflare.com/sign-up) se ainda não tiver uma.
2. Adicione seu domínio ao Cloudflare e siga as instruções para configurar os nameservers.
3. Na dashboard do Cloudflare, vá para "SSL/TLS" > "Origin Server".
4. Clique em "Create Certificate".
5. Escolha "Origin Server" e selecione "Generate Private Key and CSR".
6. Preencha as informações necessárias e clique em "Next".
7. Copie o certificado e a chave privada gerados e salve-os em arquivos separados no seu servidor (por exemplo, `cloudflare.pem` e `cloudflare.key`).

### 13.2 Configurar Acesso para IP Específico e Porta

1. Abra o arquivo `server.js` na raiz do projeto e atualize-o com o seguinte conteúdo:

```javascript file="server.js"
const { createServer } = require('https');
const { parse } = require('url');
const next = require('next');
const fs = require('fs');

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();

const httpsOptions = {
  key: fs.readFileSync('./ssl/cloudflare.key'),
  cert: fs.readFileSync('./ssl/cloudflare.pem')
};

const PORT = 3000;
const IP = '192.168.1.200';

app.prepare().then(() => {
  createServer(httpsOptions, (req, res) => {
    const parsedUrl = parse(req.url, true);
    handle(req, res, parsedUrl);
  }).listen(PORT, IP, (err) => {
    if (err) throw err;
    console.log(`> Ready on https://${IP}:${PORT}`);
  });
});

