# Manual do Administrador - Sistema Financeiro Pessoal

[... conteúdo anterior ...]

## 11. Credenciais de Acesso do Administrador

### 11.1 Senha Inicial do Administrador

A senha inicial para o acesso de administrador é:

