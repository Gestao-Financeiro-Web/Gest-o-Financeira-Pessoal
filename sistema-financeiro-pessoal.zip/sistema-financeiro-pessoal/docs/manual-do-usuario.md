# Manual do Usuário - Sistema Financeiro Pessoal

[... conteúdo anterior ...]

## 11. Licença de Uso

O Sistema Financeiro Pessoal é licenciado sob os termos da Licença de Uso do Sistema Financeiro Pessoal, copyright (c) 2024-2025 Renilson S. Ferreira. Todos os direitos reservados.

### 11.1 Resumo da Licença

- Você tem permissão para usar o software para fins pessoais ou comerciais.
- Você não pode copiar, modificar, distribuir, vender, alugar ou sublicenciar o software sem permissão expressa.
- O software é fornecido "como está", sem garantias.
- O desenvolvedor não é responsável por quaisquer danos decorrentes do uso do software.

### 11.2 Termos Completos da Licença

Para ler os termos completos da licença, por favor, consulte o arquivo LICENSE.txt incluído com o software ou acesse [link para a licença online].

### 11.3 Aceitação da Licença

Ao usar o Sistema Financeiro Pessoal, você concorda em ficar vinculado aos termos da Licença. Se você não concordar com estes termos, não use o software.

### 11.4 Contato para Questões de Licença

Para quaisquer dúvidas sobre a licença, entre em contato com Renilson S. Ferreira em renilson.ferreira@exemplo.com.

[... resto do conteúdo ...]

