import subprocess
import webbrowser
import time
import os

def start_nextjs_app():
    # Change to the directory containing your Next.js app
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Start the Next.js app
    process = subprocess.Popen(["npm", "start"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for the app to start
    time.sleep(5)  # Adjust this value if needed
    
    # Open the default web browser
    webbrowser.open('http://localhost:3000')
    
    return process

if __name__ == "__main__":
    app_process = start_nextjs_app()
    
    try:
        # Keep the script running
        app_process.wait()
    except KeyboardInterrupt:
        # Handle Ctrl+C
        app_process.terminate()
        print("Application terminated.")

