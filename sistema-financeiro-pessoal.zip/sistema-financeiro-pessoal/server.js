const { createServer } = require('https');
const { parse } = require('url');
const next = require('next');
const fs = require('fs');
const morgan = require('morgan');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();

const httpsOptions = {
  key: fs.readFileSync(process.env.SSL_KEY_PATH),
  cert: fs.readFileSync(process.env.SSL_CERT_PATH)
};

const PORT = process.env.PORT || 3000;
const IP = process.env.IP || '0.0.0.0';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});

const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000, // 15 minutes
  delayAfter: 100, // allow 100 requests per 15 minutes, then...
  delayMs: 500 // begin adding 500ms of delay per request above 100
});

app.prepare().then(() => {
  const server = createServer(httpsOptions, (req, res) => {
    // Apply rate limiting
    limiter(req, res, () => {});
    speedLimiter(req, res, () => {});

    // Use Helmet for security headers
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          imgSrc: ["'self'", "data:", "https:"],
        },
      },
    })(req, res, () => {});

    // Logging
    morgan('combined')(req, res, (err) => {
      if (err) console.error(err);
    });

    const parsedUrl = parse(req.url, true);
    handle(req, res, parsedUrl);
  });

  server.listen(PORT, IP, (err) => {
    if (err) throw err;
    console.log(`> Ready on https://${IP}:${PORT}`);
  });
});

