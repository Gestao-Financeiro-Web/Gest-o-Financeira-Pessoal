import React, { createContext, useContext, useReducer, ReactNode } from 'react'

type State = {
  user: {
    id: string
    name: string
    email: string
  } | null
  transactions: Array<{
    id: string
    amount: number
    description: string
    category: string
    date: string
    type: 'income' | 'expense'
  }>
  goals: Array<{
    id: string
    name: string
    targetAmount: number
    currentAmount: number
    deadline: string
  }>
}

type Action =
  | { type: 'SET_USER'; payload: State['user'] }
  | { type: 'SET_TRANSACTIONS'; payload: State['transactions'] }
  | { type: 'ADD_TRANSACTION'; payload: State['transactions'][0] }
  | { type: 'SET_GOALS'; payload: State['goals'] }
  | { type: 'ADD_GOAL'; payload: State['goals'][0] }
  | { type: 'UPDATE_GOAL'; payload: State['goals'][0] }

const initialState: State = {
  user: null,
  transactions: [],
  goals: [],
}

const GlobalContext = createContext<{
  state: State
  dispatch: React.Dispatch<Action>
}>({
  state: initialState,
  dispatch: () => null,
})

const globalReducer = (state: State, action: Action): State => {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload }
    case 'SET_TRANSACTIONS':
      return { ...state, transactions: action.payload }
    case 'ADD_TRANSACTION':
      return { ...state, transactions: [action.payload, ...state.transactions] }
    case 'SET_GOALS':
      return { ...state, goals: action.payload }
    case 'ADD_GOAL':
      return { ...state, goals: [action.payload, ...state.goals] }
    case 'UPDATE_GOAL':
      return {
        ...state,
        goals: state.goals.map((goal) =>
          goal.id === action.payload.id ? action.payload : goal
        ),
      }
    default:
      return state
  }
}

export const GlobalProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(globalReducer, initialState)

  return (
    <GlobalContext.Provider value={{ state, dispatch }}>
      {children}
    </GlobalContext.Provider>
  )
}

export const useGlobalState = () => useContext(GlobalContext)

