const translations = {
  'en': {
    budgets: 'Budgets',
    addNewBudget: 'Add New Budget',
    budgetList: 'Budget List',
    spent: 'Spent',
    addBudget: 'Add Budget',
    budgetWarning: 'Warning: You have spent {percentage}% of your budget for {category}.',
    budgetExceeded: 'Alert: You have exceeded your budget for {category}.',
    alertThreshold: 'Alert Threshold',
    selectMonth: 'Select Month',
    selectYear: 'Select Year',
    budgetComparison: 'Budget Comparison',
    budgeted: 'Budgeted',
  },
  'pt-BR': {
    budgets: 'Orçamentos',
    addNewBudget: 'Adicionar Novo Orçamento',
    budgetList: 'Lista de Orçamentos',
    spent: 'Gasto',
    addBudget: 'Adicionar Orçamento',
    budgetWarning: 'Aviso: Você gastou {percentage}% do seu orçamento para {category}.',
    budgetExceeded: 'Alerta: Você excedeu seu orçamento para {category}.',
    alertThreshold: 'Limite de Alerta',
    selectMonth: 'Selecionar Mês',
    selectYear: 'Selecionar Ano',
    budgetComparison: 'Comparação de Orçamentos',
    budgeted: 'Orçado',
  }
};

